let numero = prompt (" ingresa un numero")

if ( numero % 1000 === 0){

             alert ( " Ganaste un premio")
 
         }
             else {
                
                 alert (numero + " Lo sentimos siga participando" )
             }