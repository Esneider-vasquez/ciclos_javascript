

/* punto 1 */
let numero = prompt ("Valor del numero")
       if ( numero %2 === 0){
            document.write("multiplo de 2")
        }
            else {
                document.write("no es multiplo de 2")
            }
     

