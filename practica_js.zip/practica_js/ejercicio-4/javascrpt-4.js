let numero = prompt (" ingresa el primer numero")
let numero2 = prompt (" ingresa el segundo numero")

if ( numero < numero2 ){

             alert ( numero + "  es menor que " + numero2)
 
         }
             else {
                
                 alert (numero2 + "  es menor que " + numero )
}