const matorral = [];



for (var granja = 0;granja < 5; granja++) {
    let animal = prompt("Deme un animal");
    matorral.push(animal);
}

console.log(matorral);
