let lista = [1, 4, 6, 10, 22, 55, 46, 2, 5, 0]

for (let i = 0; i < 11 ; i++) {    
  console.log(lista[i])
}



  