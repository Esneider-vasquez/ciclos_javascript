

/* punto 1 */
let numero = prompt ("Valor del numero")
       if ( numero % 2 === 0){
   /*          document.write("Si es par") */
            alert ("SI es par")

        }
            else {
           /*      document.write("no es par") */
                alert ("NO es par")
            }